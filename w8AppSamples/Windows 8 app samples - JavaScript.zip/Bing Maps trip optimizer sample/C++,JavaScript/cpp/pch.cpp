﻿// pch.cpp : source file that includes just the standard includes
//   pch.pch will be the pre-compiled header
//   pch.obj will contain the pre-compiled type information

#include "pch.h"

// TODO: reference any additional headers you need in PCH.H and not in this file
