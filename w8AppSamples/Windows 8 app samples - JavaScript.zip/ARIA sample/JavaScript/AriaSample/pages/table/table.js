﻿(function () {
    "use strict";

    var appViewState = Windows.UI.ViewManagement.ApplicationViewState;
    var binding = WinJS.Binding;
    var nav = WinJS.Navigation;
    var ui = WinJS.UI;
    var utils = WinJS.Utilities;

    ui.Pages.define("/pages/table/table.html", {

        // This function updates the page layout in response to viewState changes.
        updateLayout: function (element, viewState) {
        },

    });
})();
